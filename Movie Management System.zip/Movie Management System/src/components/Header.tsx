function Header() {
  return (
    <header className="header">

      <div>
        <div className="logo">
          🎬 Movie<span>MS</span>
        </div>

        <p>
          Movie Management System
        </p>
      </div>

    </header>
  );
}

export default Header;